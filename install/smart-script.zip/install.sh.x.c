#if 0
	shc Version 4.0.3, Generic Shell Script Compiler
	GNU GPL Version 3 Md Jahidul Hamid <jahidulhamid@yahoo.com>

	shc -r -f install.sh -o smartking_setup 
#endif

static  char data [] = 
#define      pswd_z	256
#define      pswd	((&data[64]))
	"\303\153\012\032\001\274\064\130\276\025\012\007\163\170\044\345"
	"\260\131\232\212\331\026\237\002\344\045\235\003\050\233\326\354"
	"\006\341\006\007\235\073\140\134\120\152\144\304\343\211\252\223"
	"\342\104\036\273\133\276\275\100\343\132\103\014\366\032\370\374"
	"\111\160\015\237\067\075\236\133\242\067\061\046\006\156\156\250"
	"\256\177\215\127\372\014\357\122\220\175\312\242\232\316\122\344"
	"\077\137\203\167\235\042\323\077\132\005\146\141\164\324\011\042"
	"\123\227\172\116\243\151\240\064\347\153\327\202\072\051\146\172"
	"\210\352\361\045\014\305\145\147\312\314\310\076\240\322\140\364"
	"\151\333\102\015\105\343\102\055\117\031\257\211\102\025\004\313"
	"\377\366\361\014\273\127\163\205\043\074\303\304\016\044\270\170"
	"\000\373\205\105\336\307\163\055\341\042\267\044\070\273\357\070"
	"\261\341\104\155\070\270\362\134\364\266\040\003\333\331\173\334"
	"\324\000\042\263\310\225\340\251\267\230\315\360\124\275\050\006"
	"\236\155\163\327\046\146\063\032\035\124\035\370\056\230\325\002"
	"\231\367\265\142\214\226\014\104\057\331\064\204\227\134\212\066"
	"\312\376\015\360\144\101\012\202\226\050\172\304\301\120\306\132"
	"\107\174\274\323\023\310\027\103\242\113\307\072\250\121\160\162"
	"\120\176\142\265\300\155\067\126\225\262\032\127\002\341\261\111"
	"\136\156\034\161\067\064\264\332\200\174\024\050\316\205\233\036"
	"\373\377\004\231\072\144\365\213\316\132\120\262\343\372\105\305"
	"\077\144\201\233\042\076\333\005\231\036\022\217\070\013\214\063"
	"\012\220\315\105\365\302\321\304\034\041\166\377\034\274\305\134"
	"\040\106\367\102\205"
#define      text_z	2077
#define      text	((&data[521]))
	"\361\133\257\051\146\073\135\161\314\052\266\302\355\210\206\012"
	"\252\374\012\306\270\317\042\331\026\031\034\233\354\145\273\335"
	"\300\152\006\046\246\144\230\162\217\116\064\174\327\273\207\201"
	"\270\221\107\161\140\152\112\167\204\146\023\160\314\316\115\214"
	"\070\124\263\336\270\113\121\110\232\206\305\161\102\114\362\372"
	"\335\072\153\076\245\266\265\051\035\311\231\351\227\346\165\320"
	"\073\051\257\363\164\001\074\016\207\001\200\311\116\163\304\053"
	"\256\060\152\123\347\040\174\004\351\026\355\200\375\143\121\070"
	"\214\000\054\001\001\150\020\211\152\220\123\270\003\027\344\261"
	"\110\116\005\057\141\217\200\052\243\267\047\123\104\277\221\377"
	"\173\072\075\074\345\063\314\051\033\162\366\307\125\100\240\273"
	"\112\077\171\165\171\153\100\215\235\066\307\214\022\246\104\367"
	"\312\262\260\041\156\250\077\230\134\005\166\264\210\225\006\161"
	"\361\362\126\257\374\076\076\143\124\241\040\231\065\264\330\155"
	"\332\112\040\162\117\264\146\073\306\015\205\074\164\336\256\350"
	"\265\357\252\375\130\025\214\175\101\255\215\353\376\067\154\147"
	"\020\340\233\124\341\373\131\267\317\253\323\004\377\362\235\176"
	"\275\252\022\133\246\243\341\253\311\356\247\261\307\007\042\036"
	"\313\325\276\166\323\334\007\277\102\052\055\250\271\167\300\362"
	"\034\212\100\213\333\327\327\234\143\122\230\013\157\367\074\225"
	"\120\234\301\305\171\160\146\175\124\166\040\312\132\120\176\317"
	"\307\065\215\103\237\020\267\176\263\206\217\053\035\355\132\135"
	"\146\245\343\246\131\374\225\356\305\365\163\233\136\242\042\014"
	"\244\267\363\042\317\103\250\203\340\377\026\335\044\020\315\376"
	"\076\347\000\014\235\251\020\153\362\225\041\004\307\052\211\375"
	"\014\337\130\363\371\246\062\355\246\253\371\166\321\112\137\205"
	"\173\116\051\000\234\026\233\264\333\076\240\113\105\052\006\310"
	"\121\207\331\133\010\270\223\011\001\317\234\061\071\020\343\173"
	"\150\055\324\000\071\335\205\372\227\022\260\267\320\105\235\376"
	"\327\052\223\227\026\364\324\261\330\350\254\264\370\160\004\374"
	"\017\157\262\135\216\035\013\354\060\240\310\066\003\242\154\307"
	"\073\155\241\122\043\326\165\136\321\126\252\120\364\317\265\060"
	"\240\026\314\206\113\157\264\133\234\316\337\027\113\266\127\264"
	"\066\040\156\165\124\301\022\052\054\246\376\372\245\045\304\005"
	"\163\152\040\301\160\147\354\236\015\374\102\334\354\310\170\257"
	"\271\036\013\235\366\267\221\247\047\030\061\007\016\237\123\230"
	"\115\017\036\247\324\046\136\177\157\315\222\006\247\110\225\205"
	"\364\223\057\264\215\055\160\322\345\240\210\012\145\004\325\152"
	"\361\212\224\140\074\056\336\337\207\102\030\262\210\034\051\230"
	"\260\161\070\014\153\270\255\244\215\273\240\306\055\032\002\377"
	"\370\217\061\063\042\244\027\353\131\040\101\061\326\163\041\111"
	"\035\205\357\023\144\301\327\231\012\265\023\102\345\030\033\370"
	"\126\046\175\024\231\242\214\176\336\053\220\136\200\326\046\106"
	"\326\176\342\302\354\347\305\341\044\070\075\256\326\010\376\366"
	"\322\274\310\017\144\025\342\065\271\141\305\154\151\355\372\056"
	"\152\324\376\317\204\267\261\327\167\032\054\165\315\173\110\225"
	"\204\365\276\107\000\356\115\360\223\370\174\044\344\347\031\342"
	"\136\072\250\156\075\307\032\224\027\120\272\315\234\341\374\103"
	"\165\325\341\223\146\033\057\000\354\200\324\337\164\134\272\015"
	"\030\026\355\173\077\237\117\010\365\045\233\130\260\176\314\035"
	"\374\213\234\325\357\361\250\054\252\275\350\315\060\133\247\367"
	"\342\055\314\162\166\155\372\347\276\226\243\253\151\306\315\364"
	"\373\333\027\267\311\062\036\252\311\043\171\140\140\130\071\320"
	"\070\106\340\225\202\126\376\051\133\345\250\042\217\356\362\331"
	"\361\134\020\062\161\324\237\330\073\140\210\352\137\012\057\227"
	"\263\147\267\200\235\002\363\176\300\333\260\262\026\247\000\104"
	"\304\372\152\325\072\014\343\073\243\072\127\070\164\154\015\144"
	"\242\147\172\307\266\341\041\200\221\275\267\336\165\261\150\363"
	"\324\101\013\334\332\320\270\115\044\307\304\076\003\251\302\263"
	"\101\365\250\111\175\323\365\251\060\166\025\143\341\002\340\172"
	"\372\264\172\107\011\345\072\107\026\121\326\321\047\143\171\237"
	"\246\363\103\067\330\375\074\252\047\333\253\303\257\273\374\255"
	"\211\253\377\113\205\056\235\144\174\350\037\346\306\260\123\072"
	"\352\271\336\355\043\203\233\356\143\157\355\336\200\341\252\266"
	"\337\103\224\210\371\347\043\023\172\073\331\034\346\302\132\045"
	"\215\344\035\373\170\301\304\213\104\100\101\106\335\103\171\165"
	"\172\262\237\325\173\304\145\372\272\047\252\151\140\237\343\042"
	"\215\335\321\062\075\211\144\274\103\127\202\375\166\211\223\346"
	"\211\175\144\311\301\326\257\006\072\204\042\157\243\127\107\113"
	"\350\065\364\076\043\131\003\217\345\155\225\104\074\235\257\076"
	"\111\204\031\253\226\353\170\332\353\071\064\121\233\253\120\065"
	"\236\224\362\347\350\355\140\035\102\130\033\066\235\304\347\114"
	"\353\000\121\003\147\231\172\322\335\341\311\315\271\152\265\210"
	"\356\320\334\147\274\167\310\253\063\065\145\144\315\246\254\025"
	"\301\150\140\142\046\215\273\007\167\043\222\225\256\044\035\030"
	"\236\373\365\274\173\017\052\124\263\345\213\154\246\302\063\056"
	"\146\145\044\217\054\324\002\027\157\367\101\245\321\236\042\376"
	"\324\334\251\322\060\205\374\212\115\154\163\234\015\107\221\004"
	"\330\125\241\025\362\263\064\214\312\153\335\332\254\300\352\073"
	"\324\277\203\111\127\255\230\054\273\134\063\251\320\374\353\311"
	"\011\015\152\234\165\203\307\355\327\201\026\053\273\365\256\121"
	"\277\025\276\332\220\152\362\305\372\220\170\377\263\177\362\154"
	"\141\234\363\247\015\073\370\335\251\050\274\201\137\252\160\152"
	"\050\247\104\025\041\260\260\365\030\062\055\052\337\201\335\210"
	"\014\104\235\355\253\272\024\003\014\037\367\275\050\063\273\272"
	"\224\271\252\122\031\376\016\315\110\311\235\000\375\140\277\315"
	"\125\302\357\043\256\151\170\322\357\300\060\001\161\226\301\054"
	"\060\301\035\145\313\017\226\064\021\153\321\154\001\237\110\124"
	"\013\010\357\163\342\174\136\106\136\057\237\025\136\162\124\043"
	"\170\223\130\076\041\102\355\057\050\302\140\052\333\163\240\244"
	"\222\074\271\276\122\157\241\056\050\256\256\243\175\134\310\064"
	"\070\277\107\073\341\137\067\017\372\223\354\112\125\105\001\241"
	"\252\220\256\067\111\133\307\317\233\072\032\010\270\242\341\000"
	"\213\215\150\346\376\140\342\245\337\254\345\075\047\212\054\025"
	"\306\221\172\231\257\117\071\114\266\003\103\332\276\201\077\364"
	"\076\155\071\121\374\141\152\001\356\076\132\256\366\312\307\063"
	"\276\205\356\150\241\210\354\354\307\036\066\000\054\325\074\031"
	"\176\063\367\336\214\003\211\371\040\304\335\265\131\054\274\027"
	"\065\255\032\312\212\140\361\271\115\307\363\012\237\351\160\145"
	"\251\370\345\222\207\217\113\342\217\354\167\070\254\336\045\155"
	"\336\307\124\326\365\063\166\321\171\363\151\124\173\154\310\110"
	"\274\273\330\332\302\157\027\024\112\363\377\044\365\323\200\141"
	"\132\170\170\002\337\120\176\256\070\330\163\052\370\263\200\153"
	"\162\171\322\013\135\304\163\111\231\351\363\034\074\047\130\134"
	"\227\274\046\110\135\244\320\052\312\376\331\177\204\130\156\354"
	"\270\032\375\143\100\372\313\066\300\002\056\126\256\314\357\141"
	"\150\204\222\043\236\071\220\377\170\137\157\225\072\111\153\032"
	"\200\063\140\054\177\021\370\104\142\300\161\331\254\162\231\270"
	"\071\043\126\307\223\171\132\251\144\046\111\072\221\173\032\215"
	"\130\337\360\262\355\134\030\253\241\227\043\330\274\343\350\271"
	"\211\022\304\164\363\201\004\252\207\105\335\077\116\124\042\060"
	"\302\145\241\153\261\072\132\231\104\076\215\134\375\357\252\254"
	"\213\246\153\127\217\377\143\321\351\310\342\325\367\243\137\207"
	"\340\214\151\373\270\361\361\314\210\253\073\112\135\223\252\010"
	"\071\215\055\272\213\272\035\132\132\166\007\117\242\222\347\370"
	"\363\153\227\271\231\052\015\046\336\305\275\227\002\077\306\037"
	"\072\072\333\020\041\123\224\344\320\121\043\355\256\137\273\157"
	"\203\312\073\153\004\117\214\175\215\133\216\307\064\264\103\357"
	"\366\176\364\273\372\033\067\246\302\103\102\374\261\346\201\030"
	"\261\323\315\144\353\124\062\322\047\143\365\014\275\110\175\304"
	"\355\334\010\373\357\056\024\057\220\346\017\244\341\345\111\052"
	"\077\203\135\301\344\113\171\125\050\154\125\316\125\313\132\112"
	"\273\362\153\020\120\120\123\120\317\035\273\141\231\272\242\053"
	"\127\102\344\136\111\217\170\045\326\030\157\052\242\330\133\330"
	"\276\040\263\143\351\022\111\350\153\332\164\051\103\350\223\346"
	"\303\225\210\066\325\017\301\365\140\160\235\126\074\112\224\017"
	"\131\316\135\311\314\353\377\011\332\132\150\263\120\154\162\376"
	"\254\125\173\270\160\202\206\112\341\250\135\154\374\370\111\357"
	"\156\206\330\353\307\236\004\177\320\120\064\225\240\365\203\145"
	"\055\224\105\014\312\214\224\314\044\051\275\012\075\234\100\310"
	"\203\211\054\342\231\173\350\055\175\247\077\073\257\231\375\244"
	"\136\207\222\077\266\122\034\333\370\172\161\235\166\360\274\330"
	"\111\217\357\300\260\144\101\014\260\171\112\260\111\327\336\367"
	"\015\222\012\361\067\151\366\150\251\325\242\272\271\234\260\143"
	"\346\263\010\213\210\045\231\274\345\053\244\071\372\165\050\270"
	"\056\113\300\136\122\335\262\043\367\354\164\136\117\047\142\051"
	"\205\156\275\054\030\257\350\354\025\126\214\246\045\221\343\004"
	"\017\152\147\075\210\210\142\052\063\346\313\303\160\047\240\352"
	"\311\057\326\127\257\352\262\376\062\074\354\114\272\121\242\333"
	"\067\156\201\063\127\227\041\330\224\205\051\314\022\052\371\023"
	"\053\141\043\265\313\264\010\203\270\040\147\152\150\266\157\230"
	"\045\361\314\175\211\355\125\035\162\177\352\205\252\343\230\326"
	"\105\274\213\020\160\224\224\051\264\374\223\035\263\002\266\330"
#define      chk2_z	19
#define      chk2	((&data[2663]))
	"\174\157\113\366\067\033\141\357\334\274\074\004\035\146\064\322"
	"\123\307\115\105\100\253"
#define      msg2_z	19
#define      msg2	((&data[2687]))
	"\205\147\325\151\020\245\240\106\352\005\123\163\064\100\260\342"
	"\366\375\037\315\355\224\325"
#define      msg1_z	65
#define      msg1	((&data[2717]))
	"\274\067\277\055\313\124\126\200\121\351\236\256\031\075\324\065"
	"\242\163\316\234\332\045\107\314\305\010\315\040\126\014\147\047"
	"\116\154\254\035\343\103\377\243\307\011\333\063\336\260\223\040"
	"\325\054\366\363\140\024\060\306\267\250\037\005\374\263\350\034"
	"\111\043\321\232\026\236\151\364\211\237\023\173\004\354\124\334"
	"\340\326\061\135\106\335\370"
#define      date_z	1
#define      date	((&data[2793]))
	"\344"
#define      chk1_z	22
#define      chk1	((&data[2799]))
	"\220\212\226\115\302\357\163\352\325\021\002\020\113\035\276\315"
	"\161\121\027\060\244\257\212\365\273\262\140\126\173\216\252\321"
#define      shll_z	10
#define      shll	((&data[2828]))
	"\255\377\214\136\055\066\024\215\364\324\043\173\250\002"
#define      tst2_z	19
#define      tst2	((&data[2842]))
	"\016\345\211\272\316\361\337\071\031\213\111\250\274\236\277\067"
	"\153\100\221\071\374\036\353\335\107"
#define      inlo_z	3
#define      inlo	((&data[2865]))
	"\254\012\371"
#define      xecc_z	15
#define      xecc	((&data[2869]))
	"\135\256\017\042\324\372\101\253\345\032\167\016\350\112\171\353"
	"\331"
#define      rlax_z	1
#define      rlax	((&data[2885]))
	"\007"
#define      lsto_z	1
#define      lsto	((&data[2886]))
	"\161"
#define      tst1_z	22
#define      tst1	((&data[2891]))
	"\276\152\325\146\052\036\023\231\070\341\377\270\366\211\235\261"
	"\160\370\364\006\374\051\170\214\132\123\154\261\357\104\277"
#define      opts_z	1
#define      opts	((&data[2918]))
	"\210"/* End of data[] */;
#define      hide_z	4096
#define SETUID 0	/* Define as 1 to call setuid(0) at start of script */
#define DEBUGEXEC	0	/* Define as 1 to debug execvp calls */
#define TRACEABLE	1	/* Define as 1 to enable ptrace the executable */
#define HARDENING	0	/* Define as 1 to disable ptrace/dump the executable */
#define BUSYBOXON	0	/* Define as 1 to enable work with busybox */

#if HARDENING
static const char * shc_x[] = {
"/*",
" * Copyright 2019 - Intika <intika@librefox.org>",
" * Replace ******** with secret read from fd 21",
" * Also change arguments location of sub commands (sh script commands)",
" * gcc -Wall -fpic -shared -o shc_secret.so shc_secret.c -ldl",
" */",
"",
"#define _GNU_SOURCE /* needed to get RTLD_NEXT defined in dlfcn.h */",
"#define PLACEHOLDER \"********\"",
"#include <dlfcn.h>",
"#include <stdlib.h>",
"#include <string.h>",
"#include <unistd.h>",
"#include <stdio.h>",
"#include <signal.h>",
"",
"static char secret[128000]; //max size",
"typedef int (*pfi)(int, char **, char **);",
"static pfi real_main;",
"",
"// copy argv to new location",
"char **copyargs(int argc, char** argv){",
"    char **newargv = malloc((argc+1)*sizeof(*argv));",
"    char *from,*to;",
"    int i,len;",
"",
"    for(i = 0; i<argc; i++){",
"        from = argv[i];",
"        len = strlen(from)+1;",
"        to = malloc(len);",
"        memcpy(to,from,len);",
"        // zap old argv space",
"        memset(from,'\\0',len);",
"        newargv[i] = to;",
"        argv[i] = 0;",
"    }",
"    newargv[argc] = 0;",
"    return newargv;",
"}",
"",
"static int mymain(int argc, char** argv, char** env) {",
"    //fprintf(stderr, \"Inject main argc = %d\\n\", argc);",
"    return real_main(argc, copyargs(argc,argv), env);",
"}",
"",
"int __libc_start_main(int (*main) (int, char**, char**),",
"                      int argc,",
"                      char **argv,",
"                      void (*init) (void),",
"                      void (*fini)(void),",
"                      void (*rtld_fini)(void),",
"                      void (*stack_end)){",
"    static int (*real___libc_start_main)() = NULL;",
"    int n;",
"",
"    if (!real___libc_start_main) {",
"        real___libc_start_main = dlsym(RTLD_NEXT, \"__libc_start_main\");",
"        if (!real___libc_start_main) abort();",
"    }",
"",
"    n = read(21, secret, sizeof(secret));",
"    if (n > 0) {",
"      int i;",
"",
"    if (secret[n - 1] == '\\n') secret[--n] = '\\0';",
"    for (i = 1; i < argc; i++)",
"        if (strcmp(argv[i], PLACEHOLDER) == 0)",
"          argv[i] = secret;",
"    }",
"",
"    real_main = main;",
"",
"    return real___libc_start_main(mymain, argc, argv, init, fini, rtld_fini, stack_end);",
"}",
"",
0};
#endif /* HARDENING */

/* rtc.c */

#include <sys/stat.h>
#include <sys/types.h>

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

/* 'Alleged RC4' */

static unsigned char stte[256], indx, jndx, kndx;

/*
 * Reset arc4 stte. 
 */
void stte_0(void)
{
	indx = jndx = kndx = 0;
	do {
		stte[indx] = indx;
	} while (++indx);
}

/*
 * Set key. Can be used more than once. 
 */
void key(void * str, int len)
{
	unsigned char tmp, * ptr = (unsigned char *)str;
	while (len > 0) {
		do {
			tmp = stte[indx];
			kndx += tmp;
			kndx += ptr[(int)indx % len];
			stte[indx] = stte[kndx];
			stte[kndx] = tmp;
		} while (++indx);
		ptr += 256;
		len -= 256;
	}
}

/*
 * Crypt data. 
 */
void arc4(void * str, int len)
{
	unsigned char tmp, * ptr = (unsigned char *)str;
	while (len > 0) {
		indx++;
		tmp = stte[indx];
		jndx += tmp;
		stte[indx] = stte[jndx];
		stte[jndx] = tmp;
		tmp += stte[indx];
		*ptr ^= stte[tmp];
		ptr++;
		len--;
	}
}

/* End of ARC4 */

#if HARDENING

#include <sys/ptrace.h>
#include <sys/wait.h>
#include <signal.h>
#include <sys/prctl.h>
#define PR_SET_PTRACER 0x59616d61

/* Seccomp Sandboxing Init */
#include <stdlib.h>
#include <stdio.h>
#include <stddef.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>

#include <sys/types.h>
#include <sys/prctl.h>
#include <sys/syscall.h>
#include <sys/socket.h>

#include <linux/filter.h>
#include <linux/seccomp.h>
#include <linux/audit.h>

#define ArchField offsetof(struct seccomp_data, arch)

#define Allow(syscall) \
    BPF_JUMP(BPF_JMP+BPF_JEQ+BPF_K, SYS_##syscall, 0, 1), \
    BPF_STMT(BPF_RET+BPF_K, SECCOMP_RET_ALLOW)

struct sock_filter filter[] = {
    /* validate arch */
    BPF_STMT(BPF_LD+BPF_W+BPF_ABS, ArchField),
    BPF_JUMP( BPF_JMP+BPF_JEQ+BPF_K, AUDIT_ARCH_X86_64, 1, 0),
    BPF_STMT(BPF_RET+BPF_K, SECCOMP_RET_KILL),

    /* load syscall */
    BPF_STMT(BPF_LD+BPF_W+BPF_ABS, offsetof(struct seccomp_data, nr)),

    /* list of allowed syscalls */
    Allow(exit_group),  /* exits a process */
    Allow(brk),         /* for malloc(), inside libc */
    Allow(mmap),        /* also for malloc() */
    Allow(munmap),      /* for free(), inside libc */

    /* and if we don't match above, die */
    BPF_STMT(BPF_RET+BPF_K, SECCOMP_RET_KILL),
};
struct sock_fprog filterprog = {
    .len = sizeof(filter)/sizeof(filter[0]),
    .filter = filter
};

/* Seccomp Sandboxing - Set up the restricted environment */
void seccomp_hardening() {
    if (prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0)) {
        perror("Could not start seccomp:");
        exit(1);
    }
    if (prctl(PR_SET_SECCOMP, SECCOMP_MODE_FILTER, &filterprog) == -1) {
        perror("Could not start seccomp:");
        exit(1);
    }
} 
/* End Seccomp Sandboxing Init */

void shc_x_file() {
    FILE *fp;
    int line = 0;

    if ((fp = fopen("/tmp/shc_x.c", "w")) == NULL ) {exit(1); exit(1);}
    for (line = 0; shc_x[line]; line++)	fprintf(fp, "%s\n", shc_x[line]);
    fflush(fp);fclose(fp);
}

int make() {
	char * cc, * cflags, * ldflags;
    char cmd[4096];

	cc = getenv("CC");
	if (!cc) cc = "cc";

	sprintf(cmd, "%s %s -o %s %s", cc, "-Wall -fpic -shared", "/tmp/shc_x.so", "/tmp/shc_x.c -ldl");
	if (system(cmd)) {remove("/tmp/shc_x.c"); return -1;}
	remove("/tmp/shc_x.c"); return 0;
}

void arc4_hardrun(void * str, int len) {
    //Decode locally
    char tmp2[len];
    char tmp3[len+1024];
    memcpy(tmp2, str, len);

	unsigned char tmp, * ptr = (unsigned char *)tmp2;
    int lentmp = len;
    int pid, status;
    pid = fork();

    shc_x_file();
    if (make()) {exit(1);}

    setenv("LD_PRELOAD","/tmp/shc_x.so",1);

    if(pid==0) {

        //Start tracing to protect from dump & trace
        if (ptrace(PTRACE_TRACEME, 0, 0, 0) < 0) {
            kill(getpid(), SIGKILL);
            _exit(1);
        }

        //Decode Bash
        while (len > 0) {
            indx++;
            tmp = stte[indx];
            jndx += tmp;
            stte[indx] = stte[jndx];
            stte[jndx] = tmp;
            tmp += stte[indx];
            *ptr ^= stte[tmp];
            ptr++;
            len--;
        }

        //Do the magic
        sprintf(tmp3, "%s %s", "'********' 21<<<", tmp2);

        //Exec bash script //fork execl with 'sh -c'
        system(tmp2);

        //Empty script variable
        memcpy(tmp2, str, lentmp);

        //Clean temp
        remove("/tmp/shc_x.so");

        //Sinal to detach ptrace
        ptrace(PTRACE_DETACH, 0, 0, 0);
        exit(0);
    }
    else {wait(&status);}

    /* Seccomp Sandboxing - Start */
    seccomp_hardening();

    exit(0);
}
#endif /* HARDENING */

/*
 * Key with file invariants. 
 */
int key_with_file(char * file)
{
	struct stat statf[1];
	struct stat control[1];

	if (stat(file, statf) < 0)
		return -1;

	/* Turn on stable fields */
	memset(control, 0, sizeof(control));
	control->st_ino = statf->st_ino;
	control->st_dev = statf->st_dev;
	control->st_rdev = statf->st_rdev;
	control->st_uid = statf->st_uid;
	control->st_gid = statf->st_gid;
	control->st_size = statf->st_size;
	control->st_mtime = statf->st_mtime;
	control->st_ctime = statf->st_ctime;
	key(control, sizeof(control));
	return 0;
}

#if DEBUGEXEC
void debugexec(char * sh11, int argc, char ** argv)
{
	int i;
	fprintf(stderr, "shll=%s\n", sh11 ? sh11 : "<null>");
	fprintf(stderr, "argc=%d\n", argc);
	if (!argv) {
		fprintf(stderr, "argv=<null>\n");
	} else { 
		for (i = 0; i <= argc ; i++)
			fprintf(stderr, "argv[%d]=%.60s\n", i, argv[i] ? argv[i] : "<null>");
	}
}
#endif /* DEBUGEXEC */

void rmarg(char ** argv, char * arg)
{
	for (; argv && *argv && *argv != arg; argv++);
	for (; argv && *argv; argv++)
		*argv = argv[1];
}

void chkenv_end(void);

int chkenv(int argc)
{
	char buff[512];
	unsigned long mask, m;
	int l, a, c;
	char * string;
	extern char ** environ;

	mask = (unsigned long)getpid();
	stte_0();
	 key(&chkenv, (void*)&chkenv_end - (void*)&chkenv);
	 key(&data, sizeof(data));
	 key(&mask, sizeof(mask));
	arc4(&mask, sizeof(mask));
	sprintf(buff, "x%lx", mask);
	string = getenv(buff);
#if DEBUGEXEC
	fprintf(stderr, "getenv(%s)=%s\n", buff, string ? string : "<null>");
#endif
	l = strlen(buff);
	if (!string) {
		/* 1st */
		sprintf(&buff[l], "=%lu %d", mask, argc);
		putenv(strdup(buff));
		return 0;
	}
	c = sscanf(string, "%lu %d%c", &m, &a, buff);
	if (c == 2 && m == mask) {
		/* 3rd */
		rmarg(environ, &string[-l - 1]);
		return 1 + (argc - a);
	}
	return -1;
}

void chkenv_end(void){}

#if HARDENING

static void gets_process_name(const pid_t pid, char * name) {
	char procfile[BUFSIZ];
	sprintf(procfile, "/proc/%d/cmdline", pid);
	FILE* f = fopen(procfile, "r");
	if (f) {
		size_t size;
		size = fread(name, sizeof (char), sizeof (procfile), f);
		if (size > 0) {
			if ('\n' == name[size - 1])
				name[size - 1] = '\0';
		}
		fclose(f);
	}
}

void hardening() {
    prctl(PR_SET_DUMPABLE, 0);
    prctl(PR_SET_PTRACER, -1);

    int pid = getppid();
    char name[256] = {0};
    gets_process_name(pid, name);

    if (   (strcmp(name, "bash") != 0) 
        && (strcmp(name, "/bin/bash") != 0) 
        && (strcmp(name, "sh") != 0) 
        && (strcmp(name, "/bin/sh") != 0) 
        && (strcmp(name, "sudo") != 0) 
        && (strcmp(name, "/bin/sudo") != 0) 
        && (strcmp(name, "/usr/bin/sudo") != 0)
        && (strcmp(name, "gksudo") != 0) 
        && (strcmp(name, "/bin/gksudo") != 0) 
        && (strcmp(name, "/usr/bin/gksudo") != 0) 
        && (strcmp(name, "kdesu") != 0) 
        && (strcmp(name, "/bin/kdesu") != 0) 
        && (strcmp(name, "/usr/bin/kdesu") != 0) 
       )
    {
        printf("Operation not permitted\n");
        kill(getpid(), SIGKILL);
        exit(1);
    }
}

#endif /* HARDENING */

#if !TRACEABLE

#define _LINUX_SOURCE_COMPAT
#include <sys/ptrace.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <unistd.h>

#if !defined(PT_ATTACHEXC) /* New replacement for PT_ATTACH */
   #if !defined(PTRACE_ATTACH) && defined(PT_ATTACH)
       #define PT_ATTACHEXC	PT_ATTACH
   #elif defined(PTRACE_ATTACH)
       #define PT_ATTACHEXC PTRACE_ATTACH
   #endif
#endif

void untraceable(char * argv0)
{
	char proc[80];
	int pid, mine;

	switch(pid = fork()) {
	case  0:
		pid = getppid();
		/* For problematic SunOS ptrace */
#if defined(__FreeBSD__)
		sprintf(proc, "/proc/%d/mem", (int)pid);
#else
		sprintf(proc, "/proc/%d/as",  (int)pid);
#endif
		close(0);
		mine = !open(proc, O_RDWR|O_EXCL);
		if (!mine && errno != EBUSY)
			mine = !ptrace(PT_ATTACHEXC, pid, 0, 0);
		if (mine) {
			kill(pid, SIGCONT);
		} else {
			perror(argv0);
			kill(pid, SIGKILL);
		}
		_exit(mine);
	case -1:
		break;
	default:
		if (pid == waitpid(pid, 0, 0))
			return;
	}
	perror(argv0);
	_exit(1);
}
#endif /* !TRACEABLE */

char * xsh(int argc, char ** argv)
{
	char * scrpt;
	int ret, i, j;
	char ** varg;
	char * me = argv[0];
	if (me == NULL) { me = getenv("_"); }
	if (me == 0) { fprintf(stderr, "E: neither argv[0] nor $_ works."); exit(1); }

	ret = chkenv(argc);
	stte_0();
	 key(pswd, pswd_z);
	arc4(msg1, msg1_z);
	arc4(date, date_z);
	if (date[0] && (atoll(date)<time(NULL)))
		return msg1;
	arc4(shll, shll_z);
	arc4(inlo, inlo_z);
	arc4(xecc, xecc_z);
	arc4(lsto, lsto_z);
	arc4(tst1, tst1_z);
	 key(tst1, tst1_z);
	arc4(chk1, chk1_z);
	if ((chk1_z != tst1_z) || memcmp(tst1, chk1, tst1_z))
		return tst1;
	arc4(msg2, msg2_z);
	if (ret < 0)
		return msg2;
	varg = (char **)calloc(argc + 10, sizeof(char *));
	if (!varg)
		return 0;
	if (ret) {
		arc4(rlax, rlax_z);
		if (!rlax[0] && key_with_file(shll))
			return shll;
		arc4(opts, opts_z);
#if HARDENING
	    arc4_hardrun(text, text_z);
	    exit(0);
       /* Seccomp Sandboxing - Start */
       seccomp_hardening();
#endif
		arc4(text, text_z);
		arc4(tst2, tst2_z);
		 key(tst2, tst2_z);
		arc4(chk2, chk2_z);
		if ((chk2_z != tst2_z) || memcmp(tst2, chk2, tst2_z))
			return tst2;
		/* Prepend hide_z spaces to script text to hide it. */
		scrpt = malloc(hide_z + text_z);
		if (!scrpt)
			return 0;
		memset(scrpt, (int) ' ', hide_z);
		memcpy(&scrpt[hide_z], text, text_z);
	} else {			/* Reexecute */
		if (*xecc) {
			scrpt = malloc(512);
			if (!scrpt)
				return 0;
			sprintf(scrpt, xecc, me);
		} else {
			scrpt = me;
		}
	}
	j = 0;
#if BUSYBOXON
	varg[j++] = "busybox";
	varg[j++] = "sh";
#else
	varg[j++] = argv[0];		/* My own name at execution */
#endif
	if (ret && *opts)
		varg[j++] = opts;	/* Options on 1st line of code */
	if (*inlo)
		varg[j++] = inlo;	/* Option introducing inline code */
	varg[j++] = scrpt;		/* The script itself */
	if (*lsto)
		varg[j++] = lsto;	/* Option meaning last option */
	i = (ret > 1) ? ret : 0;	/* Args numbering correction */
	while (i < argc)
		varg[j++] = argv[i++];	/* Main run-time arguments */
	varg[j] = 0;			/* NULL terminated array */
#if DEBUGEXEC
	debugexec(shll, j, varg);
#endif
	execvp(shll, varg);
	return shll;
}

int main(int argc, char ** argv)
{
#if SETUID
   setuid(0);
#endif
#if DEBUGEXEC
	debugexec("main", argc, argv);
#endif
#if HARDENING
	hardening();
#endif
#if !TRACEABLE
	untraceable(argv[0]);
#endif
	argv[1] = xsh(argc, argv);
	fprintf(stderr, "%s%s%s: %s\n", argv[0],
		errno ? ": " : "",
		errno ? strerror(errno) : "",
		argv[1] ? argv[1] : "<null>"
	);
	return 1;
}
